package com.example.gsyvideoplayer.model;

/**
 * Created by shuyu on 2016/11/11.
 */

public class VideoModel {
}
