package com.shuyu.gsyvideoplayer.listener;

import android.graphics.Bitmap;

/**
 * 截屏bitmap返回
 * Created by guoshuyu on 2017/9/21.
 */

public interface GSYVideoShotListener {
    void getBitmap(Bitmap bitmap);
}
