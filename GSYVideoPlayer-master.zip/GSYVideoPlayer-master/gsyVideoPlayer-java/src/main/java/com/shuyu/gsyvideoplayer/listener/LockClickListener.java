package com.shuyu.gsyvideoplayer.listener;

import android.view.View;

/**
 * Created by shuyu on 2016/12/20.
 */

public interface LockClickListener {
    void onClick(View view, boolean lock);
}
